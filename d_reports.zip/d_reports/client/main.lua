ESX = exports["es_extended"]:getSharedObject()


local playerCooldowns = {}

RegisterCommand('report', function(source, args, rawCommand)
    local playerId = source
    local cooldownTime = 30000

    if playerCooldowns[playerId] and GetGameTimer() < playerCooldowns[playerId] + cooldownTime then
        local remainingTime = (playerCooldowns[playerId] + cooldownTime - GetGameTimer()) / 1000
        ESX.ShowNotification(string.format("You must wait %.0f seconds before reporting again.", remainingTime))
        return
    end

    local message = table.concat(args, ' ')
    if message == '' then
        ESX.ShowNotification(Config.locale.noMessage, 'error')
    else
        -- Set the cooldown for the player
        playerCooldowns[playerId] = GetGameTimer()
        TriggerServerEvent('report:send', message)
    end
end, false)

