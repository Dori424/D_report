ESX = exports["es_extended"]:getSharedObject()
  RegisterNetEvent('report:send')
  AddEventHandler('report:send', function(message)
      local src = source
      local playerName = GetPlayerName(src)
      local playerId = src
  
      local reportMessage = string.format('ID (%d): %s', playerId, message)
  
      for _, adminId in ipairs(GetPlayers()) do

          if IsPlayerAceAllowed(adminId, 'command.report') then
              TriggerClientEvent('chat:addMessage', adminId, {
                  args = {'^1REPORT', reportMessage}
              })

              TriggerClientEvent('esx:showNotification', source, Config.locale.newReport .. '(' .. playerId .. ')')
          end
      end
  end)
  