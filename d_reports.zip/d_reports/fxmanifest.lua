fx_version "cerulean"
game "gta5"
lua54 'yes'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua'
}
server_scripts {
    "server/main.lua"
}

client_scripts {
    "client/main.lua"
}

escrow_ignore {
    'config.lua'
}