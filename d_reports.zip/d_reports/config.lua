Config = {}

Config.locale = {
    newReport = 'new report from id ',
    noMessage = 'You must provide a message to report.',
    coolDown = 'You must wait %d seconds before reporting again.'
}